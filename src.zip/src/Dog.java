public class Dog extends Mammal implements AnimalBehavior {
    private String breed;

    public Dog() {}

    public Dog(String name, int age, double weight, String order, String breed) {
        super(name, age, weight, order);
        this.breed = breed;
    }

    @Override
    public void eat() {
        System.out.println(name + " the dog is eating.");
    }

    @Override
    public void getVoice() {
        System.out.println(name + " barks.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " the dog is sleeping.");
    }
}
