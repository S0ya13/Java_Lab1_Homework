public interface AnimalName {
    static void name(String name) {
        System.out.println("Animal name: " + name);
    }
}
