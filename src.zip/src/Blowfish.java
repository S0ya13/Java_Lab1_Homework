public class Blowfish extends Fish implements AnimalBehavior {
    private int poisonLevel;

    public Blowfish() {}

    public Blowfish(String name, int age, double weight, String scaleColor, int poisonLevel) {
        super(name, age, weight, scaleColor);
        this.poisonLevel = poisonLevel;
    }

    @Override
    public void eat() {
        System.out.println(name + " the blowfish is eating.");
    }

    @Override
    public void getVoice() {
        System.out.println(name + " makes underwater clicks.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " the blowfish is sleeping.");
    }
}
