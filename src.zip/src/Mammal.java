public class Mammal extends Animal implements AnimalMove {
    protected String order;

    public Mammal() {}

    public Mammal(String name, int age, double weight, String order) {
        super(name, age, weight);
        this.order = order;
    }

    @Override
    public void eat() {
        System.out.println(name + " the mammal is eating.");
    }

    @Override
    public void getVoice() {
        System.out.println(name + " the mammal makes a sound.");
    }

    @Override
    public void move() {
        System.out.println("Mammal is walking.");
    }
}
