public class Pigeon extends Bird implements AnimalBehavior {
    private String species;

    public Pigeon() {}

    public Pigeon(String name, int age, double weight, String featherColor, String species) {
        super(name, age, weight, featherColor);
        this.species = species;
    }

    @Override
    public void eat() {
        System.out.println(name + " the pigeon is eating.");
    }

    @Override
    public void getVoice() {
        System.out.println(name + " coos.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " the pigeon is sleeping.");
    }
}
