public interface AnimalMove {
    void move();
}
