public class Main {
    public static void main(String[] args) {

        Animal[] animals = new Animal[6];

        animals[0] = new Mammal("Slonenya", 12, 5400.5, "Herbivore");
        animals[1] = new Bird("Nadiya", 1, 0.02, "Brown");
        animals[2] = new Fish("Sharkie", 3, 4.1, "Silver");
        animals[3] = new Dog("Chak", 5, 22.3, "Carnivore", "Labrador");
        animals[4] = new Blowfish("Bubly", 2, 1.3, "Yellow", 30);
        animals[5] = new Pigeon("Kurlik", 1, 0.4, "Grey", "Rock Pigeon");

        AnimalBehavior[] behaviors = new AnimalBehavior[3];
        behaviors[0] = new Dog("Chak", 5, 22.3, "Carnivore", "Labrador");
        behaviors[1] = new Blowfish("Bubly", 2, 1.3, "Yellow", 30);
        behaviors[2] = new Pigeon("Kurlik", 1, 0.4, "Grey", "Rock Pigeon");

        behaviors[0].sleep();
        behaviors[1].sleep();
        behaviors[2].sleep();

        AnimalMove[] moves = new AnimalMove[6];
        moves[0] = new Mammal();
        moves[1] = new Bird();
        moves[2] = new Fish();
        moves[3] = new Dog();
        moves[4] = new Pigeon();
        moves[5] = new Blowfish();

        for (AnimalMove a : moves) {
            a.move();
        }

        for (Animal a : animals) {
            AnimalName.name(a.getName());
        }
    }
}
