public class Fish extends Animal implements AnimalMove {
    protected String scaleColor;

    public Fish() {}

    public Fish(String name, int age, double weight, String scaleColor) {
        super(name, age, weight);
        this.scaleColor = scaleColor;
    }

    @Override
    public void eat() {
        System.out.println(name + " the fish is eating.");
    }

    @Override
    public void getVoice() {
        System.out.println(name + " the fish is silent.");
    }

    @Override
    public void move() {
        System.out.println("Fish is swimming.");
    }
}
