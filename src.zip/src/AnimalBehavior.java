public interface AnimalBehavior {
    void sleep();
}
